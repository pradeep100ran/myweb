function load_profile(){
create('app','base','div','base','');
load_profilex();
}

function load_profilex(){
create('base','pf128','div','pf128','');
create('base','pf128x','div','pf128x','');

create('pf128','top_bar','div','top_bar','');

//create('top_bar','top_bar_left','div','top_bar_left','');
//create('top_bar','top_bar_right','div','top_bar_right','');


//create('top_bar_left','top_bar_left_icon','span','top_bar_left_content','PROFILE');
//create('top_bar_right','top_bar_right_icon','span','top_bar_right_icon','Logout <i class="fa fa-sign-out">');





create('pf128','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','PK');

create('pf128x','pf129a','div','pf129a','');
create('pf128x','pf129b','div','pf129b','');
ad();
}

function ad() {
create('pf129a','mid','div','mid','');
create('mid','mid1','div','mid2','Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');
//create('mid1','','span','badgelight','9+');
//create('mid2','','span','badgelight1','9+');
//create('mid1','','span','badgelight3',my_icon('check2'));

on('click','mid1',switch_middle,'mid1');
on('click','mid2',switch_middle,'mid2');
on('click','mid3',switch_middle,'mid3');
on('click','mid4',switch_middle,'mid4');
pfsen();
}


function sm() {
var parent=ids('mid');
var child =parent.children;
for (var i = 0; i < child.length; i++) {
var current=(child[i].classList);
if(current=='mid2'){
child[i].classList = [];
child[i].classList.add('mid1');
  }
}
}

function switch_middle(element) {
sm();
toggle('remove_class',element);
toggle('set_class', element,'mid2');
scroll(element);
}


function pfsen() {
create('pf128x','mid','div','mid','');
create('pf129b','pf130','div','pf130','');
create('pf130','pf130l','div','pf130l','Name');
create('pf130','pf130r','div','pf130r','');


create('pf129b','pf131','div','pf130','');
create('pf131','pf131l','div','pf130l','Number');
create('pf131','pf131r','div','pf130r','Number');

create('pf129b','pf132','div','pf130','');
create('pf132','pf132l','div','pf130l','Email');
create('pf132','pf132r','div','pf130r','Email');
load_ddd();
}


function load_ddd(){
var name=get_local('name');
var number=get_local('number');
var email=get_local('email');
put_text('pf130r',name);
put_text('pf131r',number);
put_text('pf132r',email);
var fname=name.charAt(0);
//put_text('pf_profileImage',fname);
}