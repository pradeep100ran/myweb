function load_profile(){
create('app','base','div','base','');
create('base','profile_top','div','pf128x','');
create('base','profile_main','div','pf128','');
create('base','profile_bottom','div','sss','');
top_bar();
load_xxxx();
///main_bar();
bottom();
}


function bottom() {
create('profile_bottom','bottoms','div','profile_botto','');
create('bottoms','bottom_watchlist','div','bottom_bars bottom_active','Watchlist');
//create('bottoms','bottom_orders','div','bottam_bars bottom_deactive','Orders');
create('bottoms','bottom_orde','div','bottom_bars bottom_deactive','Orders');
create('bottoms','bottom_position','div','bottom_bars bottom_deactive','Position');
create('bottoms','bottom_profile','div','bottom_bars bottom_deactive','Profile');
}


function top_bar() {
//create('base','pf128x','div','pf128x','');
//create('pf128x','pf129a','div','pf129a','');
create('profile_top','mid','div','mid','');
create('mid','mid1','div','mid2','Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');
}



function main_bar(){
create('profile_main','pf128','div','pf128','');
create('pf128','top_bar','div','top_bar','');
create('top_bar','top_bar_left','div','top_bar_left','');
create('top_bar','top_bar_right','div','top_bar_right','');
create('top_bar_right','top_bar_right_icon','span','top_bar_right_icon','Logout <i class="fa fa-sign-out">');
create('pf128','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','PK');
}





function load_profilex(){
create('base','pf128','div','pf128','');
//create('base','pf128x','div','pf128x','');

create('pf128','top_bar','div','top_bar','');

create('top_bar','top_bar_left','div','top_bar_left','');
create('top_bar','top_bar_right','div','top_bar_right','');


//create('top_bar_left','top_bar_left_icon','span','top_bar_left_content','PROFILE');
create('top_bar_right','top_bar_right_icon','span','top_bar_right_icon','Logout <i class="fa fa-sign-out">');





create('pf128','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','PK');

create('pf128x','pf129a','div','pf129a','');
create('pf128x','pf129b','div','pf129b','');
ad();
}

function ad() {
create('pf129a','mid','div','mid','');
create('mid','mid1','div','mid2','Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');


create('mid1','','span','badgelight','9+');
create('mid2','','span','badgelight1','9+');

create('mid1','','span','badgelight3',my_icon('check2'));
on('click','mid1',switch_middle);

pfsen();
}


function switch_middle() {
toggle('remove_class','mid3');
toggle('set_class','mid3','mid2');
}


function pfsen() {
//create('pf128x','mid','div','mid','');
create('pf129b','pf130','div','pf130','');
create('pf130','pf130l','div','pf130l','Name');
create('pf130','pf130r','div','pf130r','');


create('pf129b','pf131','div','pf130','');
create('pf131','pf131l','div','pf130l','Number');
create('pf131','pf131r','div','pf130r','Number');

create('pf129b','pf132','div','pf130','');
create('pf132','pf132l','div','pf130l','Email');
create('pf132','pf132r','div','pf130r','Email');
load_ddd();
load_xxxx();
}


function load_ddd(){
var name=get_local('name');
var number=get_local('number');
var email=get_local('email');
put_text('pf130r',name);
put_text('pf131r',number);
put_text('pf132r',email);
var fname=name.charAt(0);
//put_text('pf_profileImage',fname);
}



function load_xxxx(){
create('profile_main','outer_layer','div','outer_layer','')
create('outer_layer','layer_top','div','layer_top',my_icon('user'));
}