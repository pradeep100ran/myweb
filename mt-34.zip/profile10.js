function load_bottom(){
create('app','base','div','base_div','');
create('base','profile_top','div','profile_top','');
create('base','profile_main','div','profile_main','');
create('base','profile_bottom','div','profile_bottom','');
create_bottom_bar();
}
function create_bottom_bar() {
create('profile_bottom','bottoms','div','pbottoms','');
create('bottoms','bottom_watchlist','div','pbottom_deactive','Watchlist');
create('bottoms','bottom_order','div','pbottom_deactive','Orders');
create('bottoms','bottom_position','div','pbottom_deactive','Position');
create('bottoms','bottom_profile','div','pbottom_deactive','Profile');
on('click','bottom_watchlist',switch_bottom,'bottom_watchlist');
on('click','bottom_order',switch_bottom,'bottom_order');
on('click','bottom_position',switch_bottom,'bottom_position');
on('click','bottom_profile',switch_bottom,'bottom_profile');
get_active_bottom_tab();
switch_bottom(get_local('active_bottom'));
}


function get_active_bottom_tab() {
var active_bottom=get_local('active_bottom');
if(active_bottom==''){
put_local('active_bottom','bottom_profile');
}
}

function switch_bottom(element) {
var current=get_local('active_bottom');
toggle('remove_class',current);
toggle('set_class',current,'pbottom_deactive');
put_local('active_bottom',element);
toggle('remove_class',element);
toggle('set_class', element,'pbottom_active');
profile_top_bar();
}

function profile_top_bar() {
create('profile_top','mid0','div','mid0','');
create('mid0','mid','div','mid','');
create('mid','mid1','div','mid2','My Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');


on('click', 'mid1', switch_middle, 'mid1');
on('click', 'mid2', switch_middle, 'mid2');
on('click', 'mid3', switch_middle, 'mid3');
on('click', 'mid4', switch_middle, 'mid4');
load_my_profile();
}

function switch_middle(element) {
sm();
toggle('remove_class',element);
toggle('set_class', element,'mid2');
scroll(element);
}


function sm() {
var parent=ids('mid');
var child =parent.children;
for (var i = 0; i < child.length; i++) {
var current=(child[i].classList);
if(current=='mid2'){
child[i].classList = [];
child[i].classList.add('mid1');
  }
}
}

function load_my_profile() {
clean_id('profile_main');

create('profile_main','part1','div','part1','');
create('profile_main','part2','div','part2','');
create('part1','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','PK');

create('part1', 'welcome_page', 'div', 'welcome_page', '');
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Your Personal Details');

create('part2','form_main','div','form_div','');
create('form_main','number_main', '','umain','');
create('number_main','number_left', '','uleft','');
create('number_main','number_right', '','uright','');
//create('number_left','number_prefix', '','number_prefix',my_icon('telephone'));
create('number_left', 'number_prefix', '', 'number_prefix1','Number');

create('number_right','input_numberr','div','abcd', '+91 8814827330');

create('form_main', 'name_main', '', 'umain', '');
create('name_main', 'name_left', '', 'uleft', '');
create('name_main', 'name_right', '', 'uright', '');
//create('name_left', 'name_prefix', '', 'number_prefix', my_icon('email'));

create('name_left', 'name_prefix', '', 'number_prefix1','Name');


//create('name_right', '', 'div', 'abcd', 'pradeepsheornbidhnoiushshjeushbshssbbshshhshshdbdhdhdhsbbb@gmail.com');
//create('name_right','namesa','input','abc', '', { 'placeholder': 'Name', 'autocomplete':'off' ,'type': 'tel', 'maxlength': '10' });
create('name_right', 'namonamo', 'div', 'abcd','PRADEEP SHEORAN');
//put_value('namesa','PRADEEP SHEORAN');
//toggle('disable','namesa');

create('name_right', 'name_right_icon', '', 'input_right_side_iconb', '');
create('name_right_icon','eheh', 'span','input_icon_success', my_icon('check'));


create('form_main', 'email_main', '', 'umain', '');
create('email_main', 'email_left', '', 'uleft', '');
create('email_main', 'email_right', '', 'uright', '');

//create('email_left', 'email_prefix', '', 'number_prefix', my_icon('email'));
create('email_left', 'email_prefix', '', 'number_prefix1','Email');

create('email_right', '', 'div', 'abcd', 'pradeepsheornbidhnoi@gmail.com');

on('dblclick','name_right',maardo);


var k=0;
while(k<=10){
create('form_main', 'email_main'+k, '', 'umain', '');
create('email_main'+k, 'email_left'+k, '', 'uleft', '');
create('email_main'+k, 'email_right'+k, '', 'uright', '');
create('email_left'+k, 'email_prefix'+k, '', 'number_prefix1', 'Email');
create('email_right'+k, '', 'div', 'abcd', 'pradeepsheornbidhnoi@gmail.com');
k++;
}
}


function maardo() {
remove('namonamo');
create('name_right','namonamo','input','abc', '', { 'placeholder': 'Name', 'autocomplete':'off' ,'type': 'name'});
toggle('focus','namonamo')
//create('name_right', '', 'div', 'abcd','PRADEEP SHEORAN');
}