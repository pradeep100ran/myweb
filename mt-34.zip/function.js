function fn3001_3100(...args) {
var x=base(args[0]);
if(x===1){
create('app','base','div','base_div','');
create('base','profile_top','div','profile_top','');
create('base','profile_main','div','profile_main','');
create('base','profile_bottom','div','profile_bottom','');
trigger(3002);
}

if(x===2){
create('profile_bottom','bottoms','div','pbottoms','');

create('bottoms','bottom_watchlist','div','pbottom_deactive','Watchlist');
create('bottoms','bottom_order','div','pbottom_deactive','Orders');
create('bottoms','bottom_position','div','pbottom_deactive','Position');
create('bottoms','bottom_profile','div','pbottom_deactive','Profile');
on('click','bottom_watchlist',trigger,3004,'bottom_watchlist');
on('click','bottom_order',trigger,3004,'bottom_order');
on('click','bottom_position',trigger,3004,'bottom_position');
on('click','bottom_profile',trigger,3004,'bottom_profile');
trigger(3003);
trigger(3004,get_local('active_bottom'));
}

if(x===3){
var active_bottom=get_local('active_bottom');
if(active_bottom==''){
put_local('active_bottom','bottom_profile');
}
}

if(x===4){
var element=args[1];
var current=get_local('active_bottom');
toggle('remove_class',current);
toggle('set_class',current,'pbottom_deactive');
put_local('active_bottom',element);
toggle('remove_class',element);
toggle('set_class', element,'pbottom_active');
if(element=='bottom_profile'){
trigger(3005);
}
if(element!='bottom_profile'){
clean_id('profile_top');
clean_id('profile_main');
}
}



if(x===5){
create('profile_top','mid0','div','mid0','');
create('mid0','mid','div','mid','');
create('mid','mid1','div','mid1','My Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');
on('click', 'mid1',trigger,3008, 'mid1');
on('click', 'mid2',trigger,3008, 'mid2');
on('click', 'mid3',trigger,3008, 'mid3');
on('click', 'mid4',trigger,3008, 'mid4');
trigger(3007);
trigger(3008,get_local('active_top'));
}




if(x===10){
clean_id('profile_main');
create('profile_main','part1','div','part1','');
create('profile_main','part2','div','part2','');
create('part1','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','');
create('part1', 'welcome_page', 'div', 'welcome_page', '');
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Your Personal Details');
create('part2','form_main','div','form_div','');
create('form_main', 'name_main', '', 'umain', '');
create('name_main', 'name_left', '', 'uleft', '');
create('name_main', 'name_right', '', 'uright', '');
create('name_left', 'name_prefix', '', 'number_prefix1','Name');
//create('name_left', 'name_prefix', '', 'number_prefix1',my_icon('user'));
create('name_right', 'input_name', 'div', 'abcd','');
create('name_right', 'name_right_icon', '', 'input_right_side_icon', '');
//create('name_right_icon','eheh', 'span','input_icon_success', my_icon('check'));
create('form_main','number_main', '','umain','');
create('number_main','number_left', '','uleft','');
create('number_main','number_right', '','uright','');
create('number_left', 'number_prefix', '', 'number_prefix1','Number');
create('number_right','input_number','div','abcd', '');
create('form_main', 'email_main', '', 'umain', '');
create('email_main', 'email_left', '', 'uleft', '');
create('email_main', 'email_right', '', 'uright', '');
create('email_left', 'email_prefix', '', 'number_prefix1','Email');
create('email_right', 'input_email', 'div', 'abcd', '');
trigger(3009);
}
if(x===7){
var active_top=get_local('active_top');
if(active_top==''){
put_local('active_top','mid1');
}
}
if(x===8){
var element=args[1];
var current=get_local('active_top');
toggle('remove_class',current);
toggle('set_class',current,'mid1');
put_local('active_top',element);
toggle('remove_class',element);
toggle('set_class', element,'mid2');
scroll(element);
if(element=='mid1'){
trigger(3010);
}
if(element=='mid2'){
trigger(3011);
}
if(element=='mid3'){
trigger(3012);
}
if(element=='mid4') {
trigger(3013);
}
}
if(x===9){
var name=get_local('name');
var number=get_local('number');
var email=get_local('email');
put_text('input_name',name);
put_text('input_number',number);
put_text('input_email',email);
var fname=name.charAt(0);
put_text('pf_profileImage',fname);
}
if(x===11){
clean_id('profile_main');
create('profile_main','funds','div','funds_outer','');
create('profile_main','funds2','div','funds_outer2','');
create('funds','funds_title','div','funds_title','Available Funds');
create('funds','funds_price','div','funds_price','0.00');
create('funds2','fundsw','span','funds_w','WITHDRAW');
create('funds2','fundsa','span','funds_a','ADD');
}
if(x===12){
clean_id('profile_main');
create('profile_main','titl','div','','');
create('profile_main','broker_list','div','broker_outer','');



create('titl','broker_title','div','broker_title','Select Your Broker to Link');
create('broker_list','kite','div','aho','');
create('kite', 'imagekite', 'img', 'imageb', '', { 'src': 'src/image/kite.png'});
create('kite','','div','hssc','KITE');
//create('kite','kitename','div','','Kite');
create('broker_list','','div','aho','ANGEL');
create('broker_list','','div','aho','Upstox');

create('broker_list','','div','aho','Upstox');
create('broker_list','','div','aho','Kite');
//create('broker_list','','div','broker_k','Upstox');
//create('broker_list','','div','broker_k','Upstox');

//create('profile_main','part2','div','part2','');
//create('part2','form_main','div','form_div','');
//create('form_main', 'broker_name_main', '', 'umain', '');
//create('broker_name_main', 'broker_name_left', '', 'uleft', '');
//create('broker_name_main', 'broker_name_right', '', 'uright', '');
//create('broker_name_left', 'name_prefix', '', 'number_prefix5','Name');
//create('broker_name_right', 'input_name', 'select', 'abcd','');

//create('broker_name_right','input_name','input','abc5', '', { 'placeholder': 'Name', 'autocomplete':'off' ,'type': 'text', 'maxlength': '50' });
//create('broker_name_right', 'broker_name_right_icon', '', 'input_right_side_icon', '');
}
if(x===13){
clean_id('profile_main');
}
}