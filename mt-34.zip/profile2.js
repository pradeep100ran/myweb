function load_profile(){
create('app','base','div','base','');


create('base','profile_top','div','pf128','');
create('base','profile_main','div','pf128','');
create('base','profile_bottom','div','pf128','');
top_bar();
}

function load_profilex(){
create('base','pf128','div','pf128','');
create('base','pf128x','div','pf128x','');

create('pf128','top_bar','div','top_bar','');

create('top_bar','top_bar_left','div','top_bar_left','');
create('top_bar','top_bar_right','div','top_bar_right','');


//create('top_bar_left','top_bar_left_icon','span','top_bar_left_content','PROFILE');
create('top_bar_right','top_bar_right_icon','span','top_bar_right_icon','Logout <i class="fa fa-sign-out">');





create('pf128','pf_image','div','pf_image_div','');
create('pf_image','pf_profileImage','div','pf_profile_image','PK');

create('pf128x','pf129a','div','pf129a','');
create('pf128x','pf129b','div','pf129b','');
ad();
}


function top_bar() {
create('profile_top','mid','div','mid','');
create('mid','mid1','div','mid2','Profile');
create('mid','mid2','div','mid1','Funds');
create('mid','mid3','div','mid1','Broker');
create('mid','mid4','div','mid1','Settings');


//create('mid1','','span','badgelight','9+');
//create('mid2','','span','badgelight1','9+');

create('mid3','','span','badgelight1',my_icon('exclam'));

pfsen();
}