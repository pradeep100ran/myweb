function make_request(endpoint, payload,callback,...args){
if(websocket==1){
make_request_via_websocket(endpoint,payload,callback,...args);
}
if(websocket!=1){
make_request_via_url(endpoint,payload,callback,...args);
}
}
function make_request_via_url(endpoint, payload,callback,...args){
var final_payload=JSON.parse(payload);
var array = {};
array.page = endpoint;
array.data = final_payload;
var final_array=JSON.stringify(array);
let xhr = new XMLHttpRequest();
xhr.open("POST", "https://my-trade.000webhostapp.com/apis/action.php", true);
xhr.setRequestHeader("Content-Type", "application/json");
xhr.send(final_array);
var handleResponse = xhr.onreadystatechange = function () {
if (xhr.readyState === 4) {
clearTimeout(timeoutId);
var server_response = xhr.responseText;
callback(...args,xhr.status,server_response);
}
};

var timeoutId = setTimeout(function () {
xhr.abort();
  },10000);
}



function make_request_via_websocket(endpoint, payload, callback,...args) {
  var final_payload = JSON.parse(payload);
  var array = {};
  array.page = endpoint;
  array.data = final_payload;
  var final_array = JSON.stringify(array);
  if(websocket==1){
  //alert('send '+final_array);
  global_callback = callback;
  global_args = args;
  socket.send(final_array);
  }
}




function start_websocket(){
websocket=0;
socket = new WebSocket('wss://young-abundant-petalite.glitch.me');
socket.addEventListener('message', (event) => {
    var server_response = event.data;
    //alert('received '+server_response);
    //callback(...args,200,server_response);
    global_callback(...global_args,200,server_response);
    clear_websocket_variable();
  });

  // Handle WebSocket connection closed
  socket.addEventListener('close', (event) => {
  websocket=0;
  });
  socket.addEventListener('error', (error) => {
console.error('WebSocket Error:', error);
socket.close();
  });
  
  socket.addEventListener('open', (event) => {
websocket=1;
//application_root();
  });
}



function clear_websocket_variable() {
  global_callback = undefined;
  global_argsrgs = [];
}