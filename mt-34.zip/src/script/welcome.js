function welcome_root(){
var is_login=get_local('login_status');
is_login=22;
if(is_login!=1){
trigger(0);
trigger(100);
}
if(is_login==1){
load_bottom();
}
}
function fn1_100(...args){
var x=base(args[0]);
if(x===1){
create('app','welcome','div','welcome','');
}
if(x===2){
create('welcome','base_div','div','base_div','');
}
if(x===3){
create('base_div', 'image_div', 'div', 'image_div', '');
create('image_div', 'image', 'img', 'image', '', { 'src': 'src/image/welcome_logo2.png'});
create('base_div', 'welcome_page', 'div', 'welcome_page', '');
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Enter Your Mobile Number');
create('base_div','form_main','div','form_div','');
}
if(x===4){
create('form_main','number_main', '','number_main','');
}
if(x===5){
create('number_main','number_data', '','umain','');
create('number_main','number_error_main', '','','');
}
if(x===6){
create('number_data','number_left', '','uleft','');
create('number_data','number_right', '','uright','');
}
if(x===7){
create('number_left','number_prefix', '','number_prefix',my_icon('telephone'));
}
if(x===8){
create('number_right','input_number','input','abc', '', { 'placeholder': 'Mobile Number', 'autocomplete':'off' ,'type': 'tel', 'maxlength': '10' });
create('number_right','','label', 'input_label', 'Mobile Number');
}
if(x===9){
create('number_right','number_right_icon', '','input_right_side_icon','');
}
if(x===10){
create('number_right_icon','', 'span',args[1],'');
}
if(x===11){
create('number_right_icon','mrs107', 'span',args[1],my_icon('check'));
tooltip('mrs107','Double Tap to Edit','top');
}
if(x===12){
create('number_right_icon','mrs108', 'span',args[1],my_icon('exclam'));
}

if(x===51){
clean_id('number_right_icon');
}
if(x===52){
ids("input_number").disabled = true;
}
if(x===53){
ids("input_number").focus();
}
if(x===61){
on('input','input_number',trigger,71);
}
if(x===62){
on('dblclick','input_number',trigger,74);
}

if(x===71){
trigger(51);
var number=get_value('input_number');
number=trigger(6011,number);
put_value('input_number',number);
var number_length=number.length;
if(number_length==10){
trigger(52);
trigger(10,trigger(6003));
trigger(72);
}
}
if(x===72){
var number = ids('input_number').value;
var array = [];
array.push({
        'number': number
});
var final_array = JSON.stringify(array);
make_request('check_number_registration', final_array,trigger,73);
}

if(x===73){
trigger(51);
clean_id('welcome_page');
var status=args[1];
var new_response = JSON.parse(args[2]);
var response_code = new_response.response_code;
var response_status = new_response.response_status;
var message = new_response.message;
if (status == 200) {
if (response_code == 4091) {
trigger(11, trigger(6001));
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Sign In');
trigger(500);
}
if (response_code == 4092) {
trigger(11, trigger(6001));
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Sign Up',)
trigger(300);
}
}
}
if (x ===74) {
if(ids("input_number").disabled==true){
ids("input_number").disabled =false;
trigger(53);
clean_id('name_main');
clean_id('email_main');
clean_id('password_main');
clean_id('welcome_page');
create('welcome_page', 'welcome_page_span', 'span', 'welcome_page_span', 'Enter Your Mobile Number');
}
}
if(x===100){
trigger(1);
trigger(2);
trigger(3);
trigger(4);
trigger(5);
trigger(6);
trigger(7);
trigger(8);
trigger(9);
trigger(61);
trigger(62);
}
}
function fn201_300(...args){
var x=base(args[0]);
if(x===1){
create_advance('form_main','name_main','first','','','number_main','');
}
if(x===2){
create('name_main','name_data', '','umain','');
create('name_main','name_error_main', '','','');
}
if(x===3){
create('name_data','name_left', '','uleft','');
create('name_data','name_right', '','uright','');
}
if(x===4){
create('name_left','name_prefix', '','number_prefix',my_icon('user'));
}
if(x===5){
create('name_right','input_name','input','abc', '', { 'placeholder': 'Name', 'autocomplete':'off' ,'type': 'text', 'maxlength': '50' });
create('name_right','','label', 'input_label', 'Name');
}
if(x===6){
create('name_right','name_right_icon', '','input_right_side_icon','');
}
if(x===7){
create('name_right_icon',x, 'span',args[1],my_icon('check'));
}
if(x===8){
create('name_right_icon',x, 'span',args[1],my_icon('exclam'));
}
if(x===9){
create('name_right_icon',args[0], 'span',args[1],my_icon('next'));
}

if(x===51){
ids('input_name').focus();
}
if(x===52){
clean_id('name_right_icon');
}
if(x===53){
toggle('focus','input_name');
}
if(x===54){
ids("input_name").disabled = true;
}
if(x==61){
on('input','input_name',trigger,271);
on('dblclick','input_name',trigger,272);
}
if(x==62){
on('click',209,trigger,273);
}
if(x===71){
trigger(252);
var name=trigger(6013,get_value('input_name'));
put_value('input_name',name);
var name_length=name.length;
if(name_length>=3){
var is_space=name.indexOf(' ');
if(is_space==(name_length-1)){
trigger(208,trigger(6005));
}
if(is_space!=(name_length-1)){
trigger(209,trigger(6004));
trigger(262);
}
}
}
if(x===72){
if(ids("input_name").disabled==true){
ids("input_name").disabled =false;
trigger(252);
trigger(253);
}
}
if(x===73){
trigger(252);
trigger(207,trigger(6001));
trigger(254);
trigger(400);
}
if(x===100){
trigger(201);
trigger(202);
trigger(203);
trigger(204);
trigger(205);
trigger(206);
trigger(253);
trigger(261);
}
}
function fn301_400(...args){
var x=base(args[0]);
if(x===1){
create_advance('form_main','email_main','after','number_main','','name_main','');
create('email_main','email_data', '','umain','');
create('email_main','email_error_main', '','','');

create('email_data','email_left', '','uleft','');
create('email_data','email_right', '','uright','');
}
if(x===2){
create('email_left','email_prefix', '','number_prefix',my_icon('email'));
create('email_right','input_email','input','abc', '', { 'placeholder': 'Email ID', 'autocomplete':'on' ,'type': 'email'});
create('email_right','','label', 'input_label', 'Email');
create('email_right','email_right_icon', '','input_right_side_icon','');
create('email_error_main', 'email_error', 'span', 'number_error', '');
}
if(x===51){
ids('input_email').focus();
}
if(x===52){
clean_id('email_right_icon');
}
if(x===61){
on('input','input_email',trigger,371);
}
if(x===71){
trigger(352);
clean_id('email_error');
var email=get_value('input_email').replace(/\s/g, "");
var contain=email.includes('@');
if(!contain){
}
if(contain){
var valid=trigger(6012);
if(valid==false){
create('email_right_icon','mrs1010', 'span','input_icon_danger1',my_icon('info'));
tooltip('mrs1010','Enter Email that end with @gmail.com','top');
on('click','mrs107b',trigger,500);
}
if(valid==true){
create('email_right_icon','mrs107dd', 'span','input_icon_success',my_icon('next'));
on('click','mrs107dd',trigger,372);
on('dblclick','input_email',trigger,375);
}
}
}
if(x===72){
trigger(352);
toggle('disable','input_email');
create('email_right_icon','', 'span',trigger(6003),'');
trigger(373);
}
if(x===73){
var email=get_value('input_email').replace(/\s/g, "");
var array = [];
array.push({
        'email':email
});
var final_array = JSON.stringify(array);
make_request('check_email_registration', final_array,trigger,374);
}
if(x===74){
trigger(352);
remove('email_error');
var status=args[1];
var response=args[2];
var new_response =JSON.parse(response);
var response_code = new_response.response_code;
var response_status = new_response.response_status;
var message = new_response.message;
if (status == 200) {
if (response_code == 4291) {
create('email_right_icon','', 'span','input_icon_danger',my_icon('exclam'));
trigger(7004,'email_error',message);
toggle('enable','input_email');
toggle('focus','input_email');
}
if (response_code == 4292) {
create('email_right_icon','', 'span','input_icon_success',my_icon('check'));
trigger(500);
}
}
}
if(x===75){
if(ids("input_email").disabled==true){
ids("input_email").disabled =false;
clean_id('password_main');
clean_id('email_right_icon');
toggle('focus','input_email');
}
}
if(x===100){
trigger(301);
trigger(302);
trigger(351);
trigger(361);
}
}
function fn401_500(...args) {
var x=base(args[0]);
if(x===1){
create('form_main','password_main', '','number_main','');
}
if(x===2){
create('password_main','password_data', '','umain','');
create('password_main','password_error_main', '','','');
}
if(x===3){
create('password_data','password_left', '','uleft','');
create('password_data','password_right', '','uright','');
}
if(x===4){
create('password_left','password_prefix', '','number_prefix',my_icon('lock'));
}
if(x===5){
create('password_right','input_password','input','abc', '', { 'placeholder': 'Password', 'autocomplete':'off' ,'type': 'password', 'maxlength': '20' });
create('password_right','','label', 'input_label', 'Password');
create('password_right','password_right_icon', '','input_right_side_icon','');
create('password_error_main', 'password_error', 'span', 'number_error', '');
toggle('focus','input_password');
on('keyup','input_password',trigger,471);
}
if(x===61){
on('click','mrs10003',trigger,472);
}
if(x===71){
clean_id('password_error');
clean_id('password_right_icon');
var password=get_value('input_password').replace(/\s/g, "");
put_value('input_password',password);
var password_length=password.length;
if(password_length>5){
create('password_right_icon','mrs10003', 'span','input_icon_success',my_icon('next'));
trigger(461);
}
}
if(x===72){
toggle('disable','input_password');
clean_id('password_right_icon');
create('password_right_icon','', 'span',trigger(6003),'');
var number=get_value('input_number');
var email=get_value('input_email');
var name=get_value('input_name');
var password=get_value('input_password');
if(number&&email&&name&&password){
trigger(475);
}
if(number&&!email&&!name&&password){
trigger(473);
}
}
if(x===73){
var number=get_value('input_number');
var password=get_value('input_password');
var array = [];
array.push({
        'number':number,
        'password':password
});
var final_array = JSON.stringify(array);
make_request('user_login', final_array,trigger,474);
}
if(x===74){
var status=args[1];
var response=args[2];
clean_id('password_right_icon');
var new_response =JSON.parse(response);
var response_code = new_response.response_code;
var response_status = new_response.response_status;
var message = new_response.message;
if (response_code == 4191) {
create('password_right_icon','', 'span',trigger(6001),my_icon('check'));
var data=new_response.data[0];
var userid=data.userid;
var name=data.name;
var number=data.number;
var email=data.email;
var login_hash=data.login_hash;
put_local('login_status','1');
put_local('userid',userid);
put_local('name',name);
put_local('number',number);
put_local('email',email);
put_local('login_hash',login_hash);
clean_id('welcome');
welcome_root();
}
if (response_code == 4100) {
create('password_right_icon','', 'span',trigger(6002),my_icon('exclam'));
trigger(7004,'password_error',message);
toggle('enable','input_password');
toggle('focus','input_password');
}
}
if(x===75){
var number=get_value('input_number');
var email=get_value('input_email');
var name=get_value('input_name');
var password=get_value('input_password');
var array = [];
array.push({
        'number':number,
        'email':email,
        'name':name,
        'password':password
});
var final_array = JSON.stringify(array);
make_request('user_registration', final_array,trigger,476);
}

if(x===76){
clean_id('password_right_icon');
var status=args[1];
var response=args[2];
var new_response =JSON.parse(response);
var response_code = new_response.response_code;
var response_status = new_response.response_status;
var message = new_response.message;
if(response_code==4391){
create('password_right_icon','', 'span',trigger(6001),my_icon('check'));
trigger(477);
}
}
if(x===77){
remove('form_main');
remove('welcome_page');
create('base_div','form_banner', '','form_banner','');
create('form_banner','banner_content', 'span','banner_content','Your Login is successful');
create('banner_content','banner_content6', 'span','banner_content_button','Login Here');
on('click','banner_content6',welcome_root);
}
if(x===100){
trigger(401);
trigger(402);
trigger(403);
trigger(404);
trigger(405);
}
}
function fn7001_7100(...args){
var x=base(args[0]);
if(x===3){
trigger(1005);
var name=valid_name(get_value('input_name'));
put_value('input_name',name);
var name_length=name.length;
if(name_length<3){
trigger(1302);
}
if(name_length>=3){
var is_space=name.indexOf(' ');
if(is_space==(name_length-1)){
trigger(208,trigger(6005));
}
if(is_space!=(name_length-1)){
trigger(209,trigger(6004));
trigger(103);
}
}
}

if(x===4){
var location=args[1];
var message=args[2];
remove(location);
create(location+'_main',location, 'span', 'number_error',message);
}
}
function fn6001_6100(...args){
var x=base(args[0]);
var output='';
if(x===1){
output='input_icon_success';
}
if(x===2){
output='input_icon_danger';
}
if(x===3){
output='input_icon_loader';
}
if(x===4){
output='input_icon_success1';
}
if(x===5){
output='input_icon_danger1';
}
if(x==11){
var num = args[1].match(/\d/g);
output = num ? num.join('') : '';
}
if(x===12){
var email=get_value('input_email').replace(/\s/g, "");
put_value('input_email',email);
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const allowedDomains = ["gmail.com"];
const domain = email.split('@')[1];
var output=emailRegex.test(email) && allowedDomains.includes(domain);
}
if(x===13){
var input=args[1];
var first_space=input.indexOf(' ');
var name='';
if(first_space==-1||first_space==0||first_space==1||first_space==2){
name=upper_cap(input);
}
if(first_space>2){
var fname=upper_cap(input.slice(0,first_space));
var lname=upper_cap(input.slice(first_space + 1));
name=fname+' '+lname;
}
output= name;
}
return output;
}