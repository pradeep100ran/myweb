function application_root(){
var app = new_element('', 'app','app','');
document.body.appendChild(app);
welcome_root();
}