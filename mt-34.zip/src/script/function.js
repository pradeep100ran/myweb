function clean_app() {
clean_id('app');
}
function clean_id(id){
var appDiv = ids(id);
if(appDiv){
while (appDiv.firstChild) {
appDiv.removeChild(appDiv.firstChild);
    }
}
}


function scroll(element_id){
const element =ids(element_id);
var parent=ids('mid');
var total = element.offsetLeft;
var width = element.offsetWidth;
var pw=Math.floor(parent.clientWidth);
var scroll_value=total-((pw-width)/2);
parent.scroll({
  left:scroll_value,
  behavior: 'smooth'
 });
}

function upper_cap(input){
var name=input.replace(/[^a-zA-Z]/g, '');
return name.toUpperCase();
}

function tooltip(id,title,position) {
var element =ids(id);
var tooltip = new bootstrap.Tooltip(element, {
      placement: position || 'top',
      title: title || 'Default Tooltip'
});
}
function remove(child_id) {
var child_element = ids(child_id);
if (child_element && child_element.parentNode) {
child_element.parentNode.removeChild(child_element);
 }
}
function toggle(...args) {
var action=args[0];
var id=args[1];
var element = ids(id);
if (action === "hide") {
element.style.display = "none";
}
if(action === "show"){
element.style.display = "";
 }
if(action==='focus'){
element.focus();
}
if(action==='disable'){
element.disabled = true;
}
if(action==='enable'){
element.disabled = false;
}
if(action=="remove_class"||action==='rc'){
element.classList = [];
}
if(action=='set_class'||action=='sc'){
element.classList.add(args[2]);
}
}
function on(event_type,element ,listener_function, ...args) {
const target_element = ids(element);
if (target_element) {
target_element.addEventListener(event_type, () => {
listener_function(...args);
});
}
}
function append(parent_div,child_div) {
ids(parent_div).appendChild(child_div);
}
function append_advance(parent_div, child_div,position,refrence_div){
if(refrence_div==''){
if(position==''){
ids(parent_div).appendChild(child_div);
}
if(position=='first'){
ids(parent_div).insertBefore(child_div,ids(parent_div).firstChild);
}
}
if(refrence_div!=''){
var refrence_element=ids(refrence_div);
if(position=='before'){
ids(parent_div).insertBefore(child_div,refrence_element);
}
if(position=='after'){
ids(parent_div).insertBefore(child_div,refrence_element.nextSibling);
}
}
}
function create_advance(parent, child_id,position,refrence_id,element_type, element_class, element_name, additional_attributes) {
var childElement = new_element(element_type,child_id, element_class, element_name, additional_attributes);
if(!ids(child_id)){
append_advance(parent,childElement,position,refrence_id);
}
}
function create(parent, child_id, element_type, element_class, element_name, additional_attributes) {
var childElement = new_element(element_type, child_id, element_class, element_name, additional_attributes);
if(ids(parent)){
if(!ids(child_id)){
append(parent, childElement);
}
if(ids(child_id)){
}
}
if(!ids(parent)){
alert('Parent ID'+parent+' not present in system');
}
}
function trigger(...args){
var result='';
var case_number=args[0];
if(case_number==0){
clean_app();
return;
}
var rate=100;
var base=Math.floor((case_number-1)/rate)*rate;
var low=base+1;
var high=base+rate;
var name='fn'+low+'_'+high;
if (typeof window[name] === 'function'){
result=window[name](...args);
}
return result;
}
function new_element(element_type, element_id, element_class, element_name, additional_attributes){
if (!element_type){
element_type = 'div';
}
var element = document.createElement(element_type);
if (element_name){
element.innerHTML = element_name;
}
if (element_id){
element.setAttribute('id', id_maker(element_id));
}
if (element_class){
element.setAttribute('class', element_class);
}
if (additional_attributes && typeof additional_attributes === 'object'){
for (var key in additional_attributes){
if (additional_attributes.hasOwnProperty(key) && additional_attributes[key] !== undefined && additional_attributes[key] !== null){
element.setAttribute(key, additional_attributes[key]);
}
}
}
return element;
}

function class_switcher(element, new_class, old_class) {
var elem = ids(element);
if (elem.classList.contains(old_class)) {
elem.classList.remove(old_class);
    }
if(!elem.classList.contains(new_class)) {
elem.classList.add(new_class);
    }
}
function ids(element_id){
var x=document.getElementById(id_maker(element_id));
return x;
}
function id_maker(id){
var new_id='id_'+id;
return new_id;
}
function get_local(key){
var output = localStorage.getItem(key);
if(output==null){
output='';
}
return output;
}
function put_local(key,value){
localStorage.setItem(key,value);
}
function printer(id,data){
var k=ids(id);
if(k!=null){
k.innerHTML=data;
}
}
function get_value(id){
var element=ids(id);
if(element){
 return element.value;
}
if(!element){
return '';
}
}
function put_value(id,val){
ids(id).value=val;
}
function put_text(id,text){
ids(id).innerHTML=text;
}
function base(input){
var x=input-1;
var rate=100;
 var y=input-(Math.floor(x/rate)*rate);
 return y;
}
function my_icon(request_icon) {
var icon_array = [
{icon_name: 'telephone',
value: '<i class="bi bi-telephone"></i>'},
{icon_name:'check3',
value:'<i class="bi bi-patch-check-fill"></i>'},
{icon_name:'check',
value:'<i class="bi bi-check-circle-fill"></i>'},
{icon_name:'check2',
value:'<i class="bi bi-check-circle"></i>'},
{icon_name:'edit',
value:'<i class="bi bi-pencil-square"></i>'},
{icon_name:'exclam',
value:'<i class="bi bi-exclamation-triangle"></i>'},
{icon_name:'exclam2',
value:'<i class="bi bi-patch-exclamation"></i>'},
{icon_name:'info',
value:'<i class="bi bi-info-circle"></i>'},
{icon_name:'lock',
value:'<i class="bi bi-shield-lock"></i>'},
{icon_name:'next',
value:'<i class="bi bi-forward-fill"></i>'},
{icon_name:'next2',
value:'<i class="bi bi-chevron-compact-right"></i>'},
{icon_name:'next3',
value:'<i class="bi bi-chevron-right"></i>'},
{icon_name:'email',
value:'<i class="bi bi-envelope"></i>'},
{icon_name:'user',
value:'<i class="bi bi-person"></i>'}
];
var matching_icon = icon_array.find(my_icon => my_icon.icon_name === request_icon);

return matching_icon ? matching_icon.value : '';
}