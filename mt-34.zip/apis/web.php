<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once $_SERVER['DOCUMENT_ROOT'].'/apis/function.php';
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'id19957279_fnodata');
define('DB_PASSWORD', 'Pradeep@123#');
define('DB_NAME', 'id19957279_fno');
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);



function db_check_number($number) {
//range(4000,4099)
$output='';
$link=$GLOBALS["link"];
$number =real_escape($number);
$query = "SELECT * FROM user WHERE number = '$number'";
$result = mysqli_query($link, $query);
if(!$result){
server_connection_error(mysqli_error($link));
}
if(mysqli_num_rows($result)>0){
$output=$data=hrc('4091','');
output($data,'200');
}
if(mysqli_num_rows($result)<=0){
$output=$data=hrc('4092','');
output($data,'200');
}
}


function db_user_login($number,$pass) {
//range(4100,4199)
$output='';
$link=$GLOBALS["link"];
$number =real_escape($number);
$query="SELECT userid,name,number,email,password FROM user WHERE number='".$number."'";
$result = mysqli_query($link, $query);
if(!$result){
server_connection_error(mysqli_error($link));
}
if(mysqli_num_rows($result)>0){
while($row = $result->fetch_assoc()) {
$userid=$row["userid"];
$name=$row["name"];
$number=$row["number"];
$email=$row["email"];
$password=$row["password"];
$hash=md5(md5($userid));
}
if($pass==$password){
$data=array(
'userid'=>$userid,
'name'=>$name,
'number'=>$number,
'email'=>$email,
'login_hash'=>$hash);
$output=$data=hrc('4191',$data);
output($data,'200');
}
if($pass!=$password){
$output=$data=hrc('4100','');
output($data,'401');
}
}
if(mysqli_num_rows($result)<=0){
$output=$data=hrc('4101','');
output($data,'400');
}
}



function server_connection_error($error_msg){
if(strstr($error_msg,"doesn't exist")){
$output=$data=hrc('5000','');
output($data,'500');
}
if(strstr($error_msg,"SQL syntax")){
$output=$data=hrc('5001','');
output($data,'500');
}
$output=$data=hrc('5002','');
output($data,'500');
}
?>