<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/apis/web.php';
check_post_request();



function check_post_request(){
//range(1000-1099);
$error=0;
if($_SERVER['REQUEST_METHOD']!= 'POST'){
$error=1;
$data=hrc('1000','');
output($data,'405');
}
if($error==0){
check_valid_json();
}
}


function check_valid_json(){
//range(1100,1199)
$error=0;
$json=file_get_contents('php://input');
if($json==''||null||""){
$error=1;
$data=hrc('1100','');
output($data,'400');
}
if(is_json($json)==0){
$error=1;
$data=hrc('1101','');
output($data,'400'); 
}
if($error==0){
verify_page($json);
}
}




function verify_page($json){
//range(1200,1299)
$error=0;
$raw_data= json_decode($json, true);
if($raw_data==''||null||""){
$error=1;
$data=hrc('1200','');
output($data,'400');
}

if(!isset($raw_data['page'])){
$error=1;
$data=hrc('1201','');
output($data,'400');
}
$page=real_escape($raw_data['page']);
$page_valid=is_page_available($page);
if($page_valid!=1){
$error=1;
$data=hrc('1202','');
output($data,'404');
}
verify_page_data($page,$raw_data);
}


function verify_page_data($page,$raw_data){
//range(1300,1399)
$error=0;
if(!isset($raw_data['data'])){
$error=1;
$data=hrc('1300','');
output($data,'400');
}
$data=$raw_data['data'];
$data_valid=is_nested_json($data);
if($data_valid!=1){
$error=1;
$data=hrc('1301','');
output($data,'400');
}
if($error==0){
locate_page($page,$data);
}
}






function locate_page($page,$data){
//range(1400,1499)
$error=0;
$current_length=count_total_array($data);
$valid_length=object_array_valid_length($page);
if($current_length!=$valid_length){
$error=1;
$data=hrc('1400','');
output($data,'422');
}
if($page=="check_number_registration"){
check_number_registration($page,$data[0]);
}
if($page=="user_login"){
user_login($page,$data[0]);
}
}


function user_login($page,$json){
//range(1600,1699);
$error=0;
if($json==''||null||""){
$error=1;
$data=hrc('1600','');
output($data,'400');
}

foreach($json as $m=>$am){
$$m=$am;
$valid=valid_variable($page,$m);
if($valid!=1){
$error=1;
$data=hrc('1601','');
output($data,'400');
}
}

if(strlen($number)!==10){
$error=1;
$data=hrc('1602','');
output($data,'400');  
}
if(strlen($password)<6){
$error=1;
$data=hrc('1603','');
output($data,'400');  
}
if($error==0){
db_user_login($number,$password);
}
}



function check_number_registration($page,$json){
//range(1500,1599);
$error=0;
if($json==''||null||""){
$error=1;
$data=hrc('1500','');
output($data,'400');
}

foreach($json as $m=>$am){
$$m=$am;
$valid=valid_variable($page,$m);
if($valid!=1){
$error=1;
$data=hrc('1501','');
output($data,'400');
}

if(strlen($number)!==10){
$error=1;
$data=hrc('1502','');
output($data,'400');  
}

if($error==0){
db_check_number($number);
}
}
}
?>