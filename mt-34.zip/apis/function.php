<?php
function valid_variable($page, $variable_name){
$output=0;
$valid_variable=array();
if($page=="check_number_registration"){
$valid_variable=array('number');
}
if($page=="user_login"){
$valid_variable=array('number','password');
}
if (in_array($variable_name,$valid_variable)) {
$output=1;
}
if($page==''||null||""){
$output=0;
}
if($variable_name==''||null||""){
$output=0;
}
return $output;
}

function object_array_valid_length($page){
$array=[
'check_number_registration'=>1,
'user_login'=>2,
];
if(isset($array[$page])){
return $array[$page];
}else{
return 0;
}
}



function count_total_array($objectArray){
if(!is_array($objectArray)){
return 0;
}
$count=0;
foreach($objectArray as $item){
if(is_array($item)){
$count+= count($item);
}
}
return $count;
}



function is_page_available($page){
$output=1;
$valid_pages=array('check_number_registration','user_login');
if(!in_array($page,$valid_pages)){
$output=0;
}
return $output;
}
function is_json($data){
if(empty($data)){
return 0;
}
if(is_string($data)){
json_decode($data);
return (json_last_error()==JSON_ERROR_NONE);
}elseif(is_array($data)){
json_encode($data);
return (json_last_error()==JSON_ERROR_NONE);
}
return false;
}
function is_nested_json($data){
if(is_array($data)){
foreach($data as $value){
if(is_array($value)){
return 1;
}
}
return 0;
}
return 0;
}


function is_object_array($data){
if(is_array($data)&&count($data)>0){
foreach($data as $item){
if(!is_object($item)){
return 0;
}
}
return 1;
}else{
return 0;
}
}


function hrc_map($response_code){
$statusMap=[
1000=>['failed','Method Not Allowed. Only POST requests are allowed.'],
1100=>['failed','Bad Request. Input form data cannot be empty.'],
1101=>['failed','Bad Request. JSON data is not formatted correctly.'],
1200=>['failed','Bad Request. The provided JSON cannot be processed as it is empty.'],
1201=>['failed','Bad Request. The value of the Page field is missing in the JSON.'],
1202=>['failed','Not Found. The requested part of the page is not available on the server.'],
1300=>['failed','Bad Request. The value of the Data field is missing in the JSON.'],
1301=>['failed','Bad Request. JSON should be a nested object array.'],
1400=>['failed','Unprocessable Entity. The length of the object array does not match the expected valid length.'],
1500=>['failed','Bad Request. JSON inside data field cannot be empty.'],
1501=>['failed','Unprocessable Entity. The variable does not meet the required criteria.'],
1502=>['failed','Mobile Number Should be 10 Digit Only'],
1600=>['failed','Bad Request. JSON inside data field cannot be empty.'],
1601=>['failed','Unprocessable Entity. The variable does not meet the required criteria.'],
1602=>['failed','Mobile Number Should be 10 Digit Only'],
1603=>['failed','Password Length Must be 6 or Greater'],
4000=>['failed','Problem With Database Connection'],
4091=>['login','Mobile is Already Registered'],
4092=>['signup','Mobile is Not Registered'],


4100=>['failed','Password is Wrong'],
4101=>['signup','Mobile Number not Registered'],
4191=>['success','Login Successfull'],

5000=>['login',' Database Error. Table Not Exist'],
5001=>['signup','Database Error. Invalid Syntax'],
5002=>['signup','Problem With Database Connection'],
];
$output=['response_code'=>$response_code,'response_status'=>'','message'=>''];
if(isset($statusMap[$response_code])){
list($status,$message)=$statusMap[$response_code];
$output['response_status']=$status;
$output['message']=$message;
}
return json_encode($output);
}

function hrc($response_code,$data){
$input=hrc_map($response_code);
$extra=json_decode($input,true);
$response_status=$extra['response_status'];
$message=$extra['message'];
$response=array(
'response_code'=>$response_code,
'response_status'=>$response_status,
'message'=>$message,
);
if($data!==null&&!empty($data)){
$response['data']=array($data);
}
return $response;
}


function output($data,$output_code){
if($output_code==''){
$output_code=400;
}
$data=json_encode($data);
http_response_code($output_code);
header('Content-Type: application/json; charset=utf-8');
echo($data);
exit;
}

function real_escape($value){
$return='';
if (!is_string($value)) {
$value = strval($value);
    }
for($i=0;$i<strlen($value);++$i){
$char=$value[$i];
$ord=ord($char);
if($char!=="'"&&$char!=="\""&&$char!=="\\"&&$ord>=32&&$ord<=126)
$return.=$char;
else
$return.='\\x'.dechex($ord);
}
return $return;
}
?>